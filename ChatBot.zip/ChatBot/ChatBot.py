print("Hello there, Im Mr.Grady, Your personal ChatBot")
print("May I ask for your name sir?")
name = input()
# Allows the user to imput their choice of name
print(f"Hello there {name}")
user_response = input("May I ask how you are feeling sir?")




def get_mood_bot_response(user_response):

  bot_response_happy = ("Im glad you are happy sir.")
  bot_response_sad = ("Im sorry sir, perhaps they need a good talking to sir.")
  bot_response_mad = ("Perhaps they to be corrected, if I may be so bold sir.")
# The following three commands will print a statement if 
#   the proper word (in this case) emotion is stated.
  if user_response == "happy":
    print(bot_response_happy)
    
  elif user_response == "sad":
    print(bot_response_sad)
    
  elif user_response == "mad":
    print(bot_response_mad)
    
  else:
    print("Im sorry sir, but I beg your pardon?")
# If none of the three defined emotions is replied with, the program will simply say what is defined with else.
bot_response = get_mood_bot_response(user_response)
